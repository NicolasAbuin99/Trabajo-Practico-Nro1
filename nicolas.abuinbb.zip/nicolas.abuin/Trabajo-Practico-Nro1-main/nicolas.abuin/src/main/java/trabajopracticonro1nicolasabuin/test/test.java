package trabajopracticonro1nicolasabuin.test;

import java.time.LocalDate;

import trabajopracticonro1nicolasabuin.cliente.ClienteEmpresa;
import trabajopracticonro1nicolasabuin.cliente.ClienteIndividual;
import trabajopracticonro1nicolasabuin.cuentas.CajaAhorro;
import trabajopracticonro1nicolasabuin.cuentas.Cheque;
import trabajopracticonro1nicolasabuin.cuentas.CuentaConvertibilidad;
import trabajopracticonro1nicolasabuin.cuentas.CuentaCorriente;

public class test {

    public static void main(String[] args) {
        
       
        System.out.println("INICIO DEL TEST DEL SISTEMA BANCARIO");
        

        // ----------------------------------------------------
        // 1. CREACIÓN DE CLIENTES
        // ----------------------------------------------------
        System.out.println("\n--- CREACIÓN DE CLIENTES ---");
        
        ClienteIndividual cliente1 = new ClienteIndividual(1001, "Nicolás", "Abuin", "35000000");
        ClienteEmpresa cliente2 = new ClienteEmpresa(2002, "Niko99", "30712345678L");

        System.out.println("Cliente 1: " + cliente1.toString());
        System.out.println("Cliente 2: " + cliente2.toString());


        // ----------------------------------------------------
        // 2. CAJA DE AHORRO (Cliente Individual)
        // ----------------------------------------------------
        System.out.println("\n--- TEST: CAJA DE AHORRO ---");
        CajaAhorro ca1 = new CajaAhorro(1, cliente1, 5000.0, 0.05); 

        ca1.depositarEfectivo(2000.0);
        
        // 2.1 Extraer dentro del límite
        ca1.extraerEfectivo(3000.0); 
        
        // 2.2 Intentar extraer fuera del límite (Debería fallar)
        ca1.extraerEfectivo(5000.0); 
        
        // 2.3 Cobrar Intereses
        ca1.cobrarInteres(); 


        // ----------------------------------------------------
        // 3. CUENTA CORRIENTE (Cliente Individual)
        // ----------------------------------------------------
        System.out.println("\n--- TEST: CUENTA CORRIENTE ---");
        CuentaCorriente cc1 = new CuentaCorriente(2, cliente1, 1000.0, 5000.0); // Saldo: 1000, Autorizado: 5000

        // 3.1 Extraer usando saldo disponible (1000 - 1500 = -500.0, usa descubierto)
        cc1.extraerEfectivo(1500.0); 
        
        // 3.2 Intentar extraer fuera del límite total (1000 + 5000 = 6000 total disponible)
        cc1.extraerEfectivo(6000.0); 

        // 3.3 Depositar Cheque (requiere un cheque)
        Cheque chequeEmpresa = new Cheque(3500.0, "Banco Central", LocalDate.now().plusDays(15));
        cc1.depositarCheque(chequeEmpresa); 
        
        
        // ----------------------------------------------------
        // 4. CUENTA CONVERTIBILIDAD (Cliente Empresa)
        // ----------------------------------------------------
        System.out.println("\n--- TEST: CUENTA CONVERTIBILIDAD (Dólares) ---");
        CuentaConvertibilidad cv1 = new CuentaConvertibilidad(
            3, cliente2, 10000.0, 10000.0, // Herencia de Cuenta Corriente (Pesos)
            500.0, 1000.0 // Saldo Dolares: 500, Tasa: 1000 (1 USD = 1000 ARS)
        );

        // 4.1 Operaciones en Dólares
        cv1.depositarDolares(100.0);
        cv1.extraerDolares(200.0);
        
        // 4.2 Intentar extraer fuera de saldo en Dólares (Debería fallar, sin descubierto)
        cv1.extraerDolares(500.0);

        // 4.3 Conversiones
        System.out.println("\n* Conversiones (Tasa: 1000 ARS/USD):");
        // Convertir 2000 ARS a Dólares
        cv1.convertirPesosADolares(2000.0);
        
        // Convertir 10 USD a Pesos
        cv1.convertirDolaresAPesos(10.0);
    }
}